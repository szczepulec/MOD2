
clear; close all; clc;
% load matrix
Filename = 'Amatrix10'; % base file name
File = [Filename '.dat'];
A=load(File);
[rows, cols] = size(A);
%disp(A);
% Initialize the step Matrix (B)
% 0 - empty place where knight can go
% -1 - a wall
B = A * -1;
disp(B);
exit();
% Starting position
start_row = 7
start_col = 4;
row = start_row;
col = start_col;
n = 50;
% Start from step=1
step = 1;
% Starting position marked as -3
B(start_row, start_col) = -3;
% Direction to make a next step, starting from going to north.
% 0 - north
% 1 - east
% 2 - south
% 3 - west
direction = 0;
while n > 0
 [B, row, col, step, direction] = makeOneFullStep(B, row, col, step, direction);
 disp(B);
 disp(["row=", row, "col=", col, "step=", step, "direction=", direction]);
 n = n - 1;
end
disp("A");disp(A);
disp("B");disp(B);
% Make one full step
% (1) - set steps around current position
% (2) - change direction and decided where to go next
% (3) - make a step
function [B, row, col, step, direction] = makeOneFullStep(B, row, col, step, direction)
 B = setStepsAround(B, row, col, step);
 [B, step, direction] = changeDirection(B, row, col, step, direction);
 [row, col, step] = makeStep(B, row, col, step, direction);
end
% Change direction.
% (1) - change the direction to go right, from north to east, from east to
% south etc.
% (2) - check if such move is possible, do not go if there is a wall or a
% dead end.
% (3) - if we need to make a step back mark a position as a dead end.
% (4) - if there is no way to go just exit.
function [B, step, direction] = changeDirection(B, row, col, step, direction)
 %disp(['Find direction from (',num2str(row)',',',num2str(col),') step=', num2str(step),' direction = ',num2str(direction)]);
  m = 1;
 while true
   n = 1;
   while true
     % Set a new direction
     direction = direction + 1;
     direction = mod(direction, 4);
     % Get new row and column depending on the direction.
     [new_row, new_col] = getNewRowColFromDirection(B, row, col, direction);
     disp(['Check direction = ', num2str(direction), ' value = ' num2str(B(new_row, new_col))]);
    
     % If there is a wall - do not go
     if (B(new_row, new_col) == -1)
         disp(['  wall at position (',num2str(new_row),',',num2str(new_col),')']);
     % If there is a dead end - do not go
     elseif (B(new_row, new_col) == -2)
         disp(['  dead end at position (',num2str(new_row),',',num2str(new_col),')']);
     % If there is a next step on the path - go
     elseif (B(new_row, new_col) == step)
         %disp(['new direction is = ', num2str(direction),' position (',num2str(new_row)',',',num2str(new_col),')']);
         return;
     % If there is a way to go back do not go there yet.
     else
         disp(['I was here before direction=', num2str(direction)]);
     end
     % Check if this is not a blocked place without any move possible.
     n = n + 1;
     if (n > 4)
         disp("No new path - I need to go back");
         % Mark the current possition as a dead end if we need to go back.
         B(row, col) = -2;
         break;
     end
   end
   % Make a step back.
   step = step - 1;
   % Check if this is not a blocked place without any move possible.
   m = m + 1;
   if (m > 4)
       disp("No way to go");
       exit();
   end
 end
end
% Make a step.
function [row, col, step] = makeStep(B, row, col, step, direction)
 [rows, cols] = size(B);
 disp(['Make Step from (',num2str(row),',',num2str(col),') direction=',num2str(direction)]);
 % Get new row and column depending on the direction.
 [new_row, new_col] = getNewRowColFromDirection(B, row, col, direction);
 % Do not make a step if it is out of the matrix.
 if (new_row < 1 || new_row > rows)
     disp('new row out of matrix');
     return;
 end
 if (new_col < 1 || new_col > cols)
     disp('new col out of matrix');
     return;
 end
 % Make a step.
 disp(['I am going to (',num2str(new_row),',',num2str(new_col),')']);
 row = new_row;
 col = new_col;
 % Set the new step value to the matrix.
 step = B(new_row, new_col) + 1;
 % If we reached the edge this is the end.
 if (row == 1 || row == rows|| col == 1 || col == cols)
     disp(['Exit found at possition (',num2str(row),',',num2str(col),') step=', num2str(step-10)]);
     exit();
 end
end
% Get all steps around a position and return it as a list.
function steps = getStepsAround(B, row, col)
 steps = [getStep(B,row-1,col), getStep(B,row,col+1), getStep(B,row+1,col),getStep(B,row,col-1)];
end
% Get the step value of the current position
function step = getStep(B, row, col)
 [rows, cols] = size(B);
 % If a position is outside of matrix return 0.
 if (row < 1 || row > rows)
     step = 0;
 elseif (col < 1 || col > cols)
     step = 0;
 else
     step = B(row, col);
 end
end
% Get a new possition depending on direction.
function [row, col] = getNewRowColFromDirection(B, row, col, direction)
  [rows, cols] = size(B);
 % Calculate how to modify row or column.
 row_delta = 0;
 col_delta = 0;
 if (direction == 0)
     row_delta = -1;
 elseif (direction == 1)
     col_delta = 1;
 elseif (direction == 2)
     row_delta = 1;
 elseif (direction == 3)
     col_delta = -1;
 end
 % Calculate a new row and column.
 new_row = row + row_delta;
 new_col = col + col_delta;
 % If the new possition is outside of the matrix, ignore it
 if (new_row > 0 && new_row <= rows)
     row = new_row;
 end
 if (new_col > 0 && new_col <= cols)
     col = new_col;
 end
end
% Set steps around the currne position.
function [B, step] = setStepsAround(B, row, col, step)
 disp(['set step around (',num2str(row),',',num2str(col),')']);
 B = setStep(B, row-1, col, step);
 B = setStep(B, row+1, col, step);
 B = setStep(B, row, col-1, step);
 B = setStep(B, row, col+1, step);
end
% Set step at the current position.
function B = setStep(B, row, col, step)
 [rows, cols] = size(B);
 % If a position is outside of the matrix do nothing.
 if (row > 0 && row <= rows) && (col > 0 && col <= cols)
   % If the position has been set before do nothing.
   if B(row, col) == 0
     steps = getStepsAround(B, row, col);
     for s = 1:length(steps)
         % If there is a shortest path to this position do nothing
         if steps(s) < step && steps(s) > 0
             disp(['no set step at position (',num2str(row),',',num2str(col),') because there is a shorter path ', num2str(steps(s))]);
         end
     end
     % Set the step.
     B(row,col) = step;
     disp(['set step (',num2str(row),',',num2str(col),') = ', num2str(step)])
   end
 end
end
