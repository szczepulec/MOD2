
clear; close all; clc;

Filename = 'Amatrix20'; 
File = [Filename '.dat'];
A=load(File); 

i = 7;
j = 4;

M = labyrinth(A, i, j);
disp(M)

function M = labyrinth(A, i, j)
    P = [];
    for k = 1:2000
        P = [P  oneRunszczepan(A,i,j)];
    end
    M = min(P);
end

function stepfinal = oneRunszczepan(A,i,j)


[m,n] = size(A);
B = A*-1;
stepfinal = [];

 
stepc = 0;
B(i,j) = -2;


for k = 1:200 
    [stepfinal,the_end] = shortestPath(stepfinal,stepc,A,i,j);
    if the_end == true
        break;
    end
    [B,i,j] = chooseMove(B,i,j);
    [stepc,B] = makeMove(B,i,j,stepc);
end
disp(B);
function [A, i,j] = chooseMove(A,i,j)
    % 1 - north
    % 2 - south
    % 3 - west
    % 4 - east
    steps_around = [A(i-1,j), A(i+1,j), A(i,j-1), A(i,j+1)];

    free_dirs = [];
    if steps_around(1) == 0
        free_dirs = [free_dirs, 1];
    end
    if steps_around(2) == 0
        free_dirs = [free_dirs, 2];
    end
    if steps_around(3) == 0
        free_dirs = [free_dirs, 3];
    end
    if steps_around(4) == 0
        free_dirs = [free_dirs, 4];
    end

    dir = get_dir(free_dirs);
    if dir > 0
        [i, j] = getNewPosition(dir, i, j);
        return;
    end
   
    [max_value, dir] = max(steps_around);
     if checkIfDeadEnd(steps_around, A(i,j))
        A(i,j) = -3;
     end
    [i, j] = getNewPosition(dir, i, j);
    
    function dir = get_dir(dirs)
        dir = 0;
        if isempty(dirs) == false
            p = randi([1, length(dirs)]);
            dir = dirs(p);
        end
    end

    function [i, j] = getNewPosition(dir, i, j)
        switch dir
            % north
            case 1
                i=i-1;
            % south
            case 2
                i=i+1;
            % west
            case 3
                j=j-1;
            % east
            case 4
                j=j+1;   
        end
    end

    function dead_end = checkIfDeadEnd(step_arounds, stepc)
        dead_end = false;
        nb_of_busy_pos = 0;
        the_highest_pos = true;
        for sa = step_arounds
            if sa < 0
                nb_of_busy_pos = nb_of_busy_pos + 1;
            end
            if sa > stepc
                the_highest_pos = false;
            end
        end
        if nb_of_busy_pos == 3 || the_highest_pos == true
          dead_end = true;
        end

    end
end


function [stepc,akuku] = makeMove(akuku,i,j,stepc)
    stepc = stepc + 1;
    if akuku(i,j)== 0
       akuku(i,j) = stepc;
    elseif akuku(i,j)>0
       stepc = akuku(i,j);
    elseif akuku(i,j)==-3
    end
end

function [stepfinal, the_end] = shortestPath(stepfinal,stepc,A,i,j) 
    the_end = false;
    [m,n] = size(A);
    if i == m || i == 1
        stepfinal = [stepfinal  stepc];
        the_end = true;
    elseif j == m || j == 1
        stepfinal = [stepfinal  stepc];
        the_end = true;
    end
end
end


