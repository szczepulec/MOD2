clear; close all; clc;


imie1 = 'Szczepan';
imie2 = 'Jadwiga';
i = length(imie1);
while i > 0
     disp(['imie1(',num2str(i),')=',imie1(i)]);
     i = i - 1;
end