function [i,j] = selectStartPosition(A)
    [m,n] = size(A);
    while true 
        i = randi([1,n]);
        j = randi([1,n]);
        Start_P = A(i,j);
            if Start_P == 0
                
                break
            end
    end
end