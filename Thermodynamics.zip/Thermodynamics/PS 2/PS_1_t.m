clc; clear;close all;
% 0 free to go
% 1> been there
% -1 wall
% -2 starting pos
% -3 blocked by own path
Filename = 'Amatrix10'; 
File = [Filename '.dat'];
A=load(File); 
[m,n] = size(A);
B = A*-1;
stepfinal = [];
p = 1;
pic = zeros(m*p,n*p); 

for i=1:m
    for j=1:n
            pic(p*(i-1)+1:p*i,p*(j-1)+1:p*j) = 255-A(i,j)*255; 
    end
end

stepc = 0;
i = 5;
j = 5;
B(i,j) = 0;
pic(i,j) = 120;

disp(B);


for k = 1:200 
    [stepfinal,the_end] = shortestPath(stepfinal,stepc,A,i,j);
    if the_end == true
        %disp('Espace!');
        break;
    end
    [B,i,j,no_escape] = chooseMove(B,i,j);
    if no_escape == true
        %disp('No exit!');
        break;
    end
    [stepc,B] = makeMove(B,i,j,stepc);
    %pic(i,j) = 165;
    %disp(B);
end
%disp(B);
%disp(['k=', num2str(k)]);
%disp(stepfinal);

%image(pic); 


function [A,i,j,no_escape] = chooseMove(A,i,j)
    % 1 - north
    % 2 - south
    % 3 - west
    % 4 - east
    steps_around = [A(i-1,j), A(i+1,j), A(i,j-1), A(i,j+1)];
    %disp('steps_around=');
    %disp(steps_around);
    no_escape = false;
     
    free_dirs = [];
    if steps_around(1) == 0
        free_dirs = [free_dirs, 1];
    end
    if steps_around(2) == 0
        free_dirs = [free_dirs, 2];
    end
    if steps_around(3) == 0
        free_dirs = [free_dirs, 3];
    end
    if steps_around(4) == 0
        free_dirs = [free_dirs, 4];
    end

    %disp('free_dirs=');
    %disp(free_dirs);
    dir = get_dir(free_dirs);
    if dir > 0
        [i, j] = getNewPosition(dir, i, j);
        %disp(['chooseMove: (',num2str(i),',',num2str(j),')']);
        return;
    end
   
    [max_value, dir] = max(steps_around);
     if checkIfDeadEnd(steps_around, A(i,j))
        A(i,j) = -3;
    end

    %disp(['Max value a=', num2str(dir)])
    if max_value < 0
        no_escape = true;
        return;
    end

    [i, j] = getNewPosition(dir, i, j);
    
    function dir = get_dir(dirs)
        dir = 0;
        if isempty(dirs) == false
            p = randi([1, length(dirs)]);
            dir = dirs(p);
        end
    end

    function [i, j] = getNewPosition(dir, i, j)
        switch dir
            % north
            case 1
                i=i-1;
            % south
            case 2
                i=i+1;
            % west
            case 3
                j=j-1;
            % east
            case 4
                j=j+1;   
        end
        %disp(['getNewPosition (',num2str(i),',',num2str(j),')']);
    end

    function dead_end = checkIfDeadEnd(step_arounds, stepc)
        dead_end = false;
        nb_of_busy_pos = 0;
        the_highest_pos = true;
        for sa = step_arounds
            if sa < 0
                nb_of_busy_pos = nb_of_busy_pos + 1;
            end
            if sa > stepc
                the_highest_pos = false;
            end
        end
        if nb_of_busy_pos == 3 || the_highest_pos == true
          %disp(['checkIfDeadEnd (',num2str(i),',',num2str(j),')']);
          dead_end = true;
        end
    end
end


function [stepc,akuku] = makeMove(akuku,i,j,stepc)
    stepc = stepc + 1;
    if akuku(i,j)== 0
       akuku(i,j) = stepc;
       %disp(['makeMove (', num2str(i), ',', num2str(j), ') zero']);
    elseif akuku(i,j)>0
       stepc = akuku(i,j);
       %disp(['We were here: (',num2str(i),',',num2str(j),')']);
       %akuku(i,j) = -3;
    elseif akuku(i,j)==-3
       %disp(['dead end (', num2str(i), ',', num2str(j), ')']);
    end
end

function [stepfinal, the_end] = shortestPath(stepfinal,stepc,A,i,j) 
    the_end = false;
    [m,n] = size(A);
    if i == m || i == 1
        stepfinal = [stepfinal  stepc + 1];
        the_end = true;
    elseif j == m || j == 1
        stepfinal = [stepfinal  stepc + 1];
        the_end = true;
    end
end