% create a picture of the matrix and store as .png file.
% the matrix is increase p-fold to get a reasonable picture size

clear all;
close all;
clc;

% load matrix
Filename = 'Amatrix20'; % base file name
File = [Filename '.dat'];
A=load(File); 
[m,n] = size(A);

p = 1; % increase pixel p-fold
pic = zeros(m*p,n*p); % create space for final picture

for i=1:m
    for j=1:n
            pic(p*(i-1)+1:p*i,p*(j-1)+1:p*j) = 255-A(i,j)*255; % scales and inverts the 
    end
end
% show maze
image(pic); % increase contrast and invert the colors
% % save picture
% Picturefile = [Filename '.png'];
% imwrite(pic,Picturefile)