function list_Nprime = getPrimeNumbers(N)
    list_n = 2:N;
    list_n = findP(list_n,2);
    list_n = findP(list_n,3);
    list_n = findP(list_n,5);
    list_n = findP(list_n,7);
            
       function list_m = findP(list_n,D)
        list_m  = list_n;
         for i = list_n
          m = i * D;
          %disp(['i=', num2str(i), ' m=', num2str(m)]);
            if ismember(m, list_n)
                %disp(['usun ', num2str(m)]);
                j = find(list_n==m);
                list_m(j) = 0;
                %disp(['j=', num2str(j)]);
                %list_m(list_m==0)= [];
            end
         end
       end

    list_Nprime = list_n;
    list_Nprime(list_Nprime==0)= [];
end