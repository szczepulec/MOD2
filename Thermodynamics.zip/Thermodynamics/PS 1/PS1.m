clear; close all; clc;

N = 8724;
test = getPrimeNumbers(N);
display(test)

