function list_hull_index = getConvexHull(x, y)

j = find(y==min(y),1); %index of the first point on the hull
p = 3.1415926; % pi
p_fraction = 3*p/2; %3*pi/2

list_hull_index = []; %empty array for answer
list_hull_index(1) = j; %adding index of the first point to the answer
% creating new coordinates with respect to first point on th hull as origin
y = y - y(j);
x = x - x(j);
angle = atan2(y, x); % angles of points in new coordinates
sort_angle = sort(angle); % array of angles sorted from lowest to highest

min_angle_ind = find(angle == sort_angle(2)); % index of the second point on the hull
list_hull_index(end+1)=min_angle_ind; % adding index of the second point to the answer
% these are numbers for implementing conditions in the for-loop. They
% should be high to not intervene with cases not requiring special
% conditions
y_max_hull_number = 1000;
x_min_hull_number = 1000;
for q =1:length(x)
    j = min_angle_ind; % index of the latest point found on the hull
    %new coordinates with respect to the new origin, which is latest point
    %on the hull
    y = y - y(j);
    x = x - x(j);
    angle = atan2(y, x); % angles of points in new coordinates
    negative_angle_index = find(angle<0); % looking for angles with negative values
    angle(negative_angle_index) = angle(negative_angle_index)+2*p; % adding 2pi to negative angles to make all angles in the array positive without changing tan value
    sort_angle = sort(angle); %array of angles sorted from lowest to highest (this is why negative angles were changed
    if y(j) == max(y)
        y_max_hull_number = length(list_hull_index); %index of the absolute maximum, when hull reaches it
    end
    if x(j) == min(x)
        x_min_hull_number = length(list_hull_index); %index of the  maximum, when hull reaches it
    end
    if length(list_hull_index) >= x_min_hull_number
        sort_angle_1 = find(sort_angle >= p_fraction,1);
        min_angle_ind = find(angle == sort_angle(sort_angle_1));
    elseif length(list_hull_index) >= y_max_hull_number
        sort_angle_2 = find(sort_angle >= (p/2),1);
        min_angle_ind = find(angle == sort_angle(sort_angle_2));
    else
        min_angle_ind = find(angle == sort_angle(2));
    end
    list_hull_index(end+1)=min_angle_ind;
    if list_hull_index(end) == list_hull_index(1)
        break
    end
    list_hull_index = list_hull_index(1:end-1);
end
