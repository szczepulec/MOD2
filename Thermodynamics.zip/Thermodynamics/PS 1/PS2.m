clear; close all; clc;

x= [30 20 48 13 76 49 4 18];
y= [12 15 23 92 12 40 39 12];
list_hull_index = getConvexHull(x, y);
fprintf(list_hull_index)