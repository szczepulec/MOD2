
clear all;  close all; clc;

w=[1 2 3 4 5 6 7];
slot = w(randi(7))

x=[0 1 2];
rand = x(randi(3))