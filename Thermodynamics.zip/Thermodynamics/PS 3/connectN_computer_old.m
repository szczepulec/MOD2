clear; close all; clc;



promptforN = 'Enter N value:';
promptforK = 'Enter K value';


N = input(promptforN);
K = input(promptforK);

[M, turn] = initializeBoard(N,K);
checkVictory(M,N);





if checkVictory(M,N) == 1
    fprintf('GAME OVER Player %. wins \n',player)
    
elseif checkVictory(M,N) == -1
    disp('GAME OVER DRAW')
elseif checkVictory(M,N) == 0

while checkVictory(M,N) == 0
   if turn == 1
      fprintf('Player %.fs turn\n',turn)
      promptcolumm = 'Choose column';
      c = input(promptcolumm);
        
   if isColumnPossible(M,c) == 0
        while isColumnPossible(M,c) == 0
             promptcolumm2 = 'Invalid column, choose another';
             c = input(promptcolumm2);
             
        end
  end
   elseif turn == 2
      disp('Computers turn')
      c = findColumn(M);
         if isColumnPossible(M,c) == 0
      while isColumnPossible(M,c) == 0
         c = findColumn(M);
                   
      end
   end
   end
        
   addPiece(M,c,turn);
   
  end
    
end


if checkVictory(M,N) == 1 && player == 1
    fprintf('GAME OVER Player %. wins \n',player)



elseif checkVictory(M,N) == -1
    disp('GAME OVER DRAW')
    
elseif checkVictory(M,N) == 1 && player == 2
    disp('GAME OVER computer %. wins \n')
    

end


function c = findColumn(M)
    [rows, cols] = size(M);
    c = randi([1:cols]);
end







