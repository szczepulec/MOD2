clear;  
close all; 
clc;

promptforN = 'Enter N value:';
promptforK = 'Enter K value';


N = input(promptforN);
K = input(promptforK);
victory = 0;
state = true;

[M, turn] = initializeBoard(N,K);
[rows, cols] = size(M);


disp(M)
disp(['Following player stars: ', num2str(turn)])
disp('To quit enter "-1"')
while victory == 0 
    %%%% Player 1 starts
    prompt = 'Select desired columm:';
    c = input(prompt);
    
    if c == -1
       break
    elseif c > cols || c < 1
        disp('Pay attention, column is out of bounds')
        continue
    end

   

    %%%% checks

    state = isColumnPossible(M, c);
       if state == false
            disp('Pay attention, column is full') 
            continue
       end

    %%%% Player 1 input
    M = addPiece(M, c, turn);


    %%%% checks

    victory = checkVictory(M, N);
       if victory == 1
           disp(M)
           disp('Player 1 wins!!')
           break
       elseif victory == 2
           disp(M)
           disp('Player 2 wins!!')
           break
       elseif victory == -1
           disp(M)
           disp('Board is full game over, No winner!')
           break
       end
    %%%% Switch turns

        if turn == 1
              turn = 2;
        elseif  turn == 2
              turn = 1; 
        end

    disp(M)
    disp('Following players turn:')
    disp(turn)
end



