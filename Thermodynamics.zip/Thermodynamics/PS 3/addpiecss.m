clear all;  close all; clc;

%function [M, turn] = initializeBoard(N, K);

N = 6;
K = 3;
turn = 1;
%initializeBoard(N,K)
M = zeros(N+3,N+2);
c = [1,N+2];
addPiece(M, c, turn)



function M = addPiece(M, c, turn)


end