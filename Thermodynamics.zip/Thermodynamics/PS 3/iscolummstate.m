clear all;  close all; clc; 


function state = isColumnPossible(M, c)

if 












end