clear;  
close all; 
clc;

%function [M, turn] = initializeBoard(N, K);

N = 7;
K = 20;
initializeBoard(N,K)


function [M, turn] = initializeBoard(N,K)
turn = randi(2);
M = zeros(N+3,N+2);
array = zeros(1,N+2);

for i = 1:2*K
    c = randi(N+2);
        if M(N+3,c) == 0
          M(N+3,c) = turn;
        else
        
        for j=1:(N+3)
        array(j) = M(j,c);
        numbers = find(array == 0);
        n = numbers(end);
        end
        if M(N+3,c) > 0
          M(n,c) = turn;
        end
        end
        if turn == 1
           turn = 2;
        elseif turn == 2
           turn = 1; 
        end
end
end



