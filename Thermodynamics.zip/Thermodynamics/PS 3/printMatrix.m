function printMatrix(M)
%PRINTMATRIX Print matrix to command line

[rows, cols] = size(M);


sep_row = [repelem('-', cols*2+1), '\n'];

fprintf(sep_row);   
for r = 1:rows
    
    fprintf('|');
    
    for c = 1:cols
        
        if M(r,c) == 1
            char = 'x';
        elseif M(r,c) == 2
            char = 'o';
        else
            char = ' ';
        end
        
        fprintf([char, '|']);
        
    end
    fprintf('\n');
end

fprintf(sep_row);

end

