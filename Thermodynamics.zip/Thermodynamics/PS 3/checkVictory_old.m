function victory = checkVictory(M, N)


[rows, cols] = size(M);
victory = 0;
p = [];

for r = 1:rows
    for n = 0:3
        checkr = M(r,(1:N)+n);
        if prod(checkr) == 1
            victory = 1;
            p = 1;
        elseif prod(checkr) == 2^N
            victory = 1;
            p = 2;
        
            
        end
    end
end

for clmn = 1:cols
    for rn = 0:2
        checkc = M((1:N)+rn,clmn);
        if prod(checkc) == 1
            victory = 1;
            p = 1;
        elseif prod(checkc) == 2^N
            victory = 1;
            p = 2;
        end
    end
end



g = zeros(4*rows,cols);

[g_rows, g_cols] = size(g);

for k = -rows+1:rows-1
    x = diag(M,-k);
    a = diag(fliplr(M),-k);
    
    for l = 1:length(x)
        g(k+rows,l) = [x(l)];
        g(k+(3*rows),l) = [a(l)];
        
    end
end

for grow = 1:g_rows
    for ng = 0:3
        checkg = g(grow,(1:N)+ng);
        if prod(checkg) == 1
            victory = 1;
            p = 1;
        elseif prod(checkg) == 2^N
            victory = 1;
            p = 2;
        end
    end
end

if prod(M(1, 1:cols)) ~= 0 && victory ~= 1
    victory = -1;
end
assignin('base', 'p', p);

end

