


function [M, turn] = initializeBoard(N, K)