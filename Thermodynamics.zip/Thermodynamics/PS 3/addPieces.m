clear;  
close all; 
clc;

%function M = addPiece(M, c, turn)



%conditions of the player
c = 2; %input function can be used as well
turn = 1;

M = initializeBoard; % refers to matrix with added K numbers

addPiece(M, c, turn)

function M = addPiece(M, c, turn)

array_1 = M(1:end,c); %array of elements from column chosen by the player 

numbers = find(array_1); % gives an array of indices of zeros in the given column
n = numbers(end); % index of last zero
M(n,c) = turn;
end