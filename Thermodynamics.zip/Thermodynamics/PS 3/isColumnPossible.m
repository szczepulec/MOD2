
%{
clear all;  close all; clc;

%function [M, turn] = initializeBoard(N, K);

N = 6;
K = 7;
%initializeBoard(N,K)
c = randi(N+2);
M = zeros(N+3,N+2);
isColumnPossible(M, c)
%}


function state = isColumnPossible(M, c)
state = true;
    if M(1,c) > 0
       state = false;
    end
 
        
end    