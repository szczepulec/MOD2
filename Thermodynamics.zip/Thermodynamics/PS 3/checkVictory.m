function victory = checkVictory(M, N)

% -1 = no Winner FULL board game over
% 0 = no Winner 
% 1 = Player 1 wins
% 2 = Player 2 wins



[rows, cols] = size(M);
victory = -1;
p = [];


for r = 1:rows
    for l = 1:(cols-N+1)
        %disp(['l=', num2str(l)])
        %disp(['M=', num2str(M(r,l))])
        if M(r,l) == 0
            victory = 0;
            continue
        end    
        if range(M(r,l:(l+N-1))) == 0 
            victory = M(r,l);
        end

    end
end


for l = 1:cols
    for r = 1:(rows-N+1)
        %disp(['l=', num2str(l)])
        %disp(['M=', num2str(M(r,l))])
        if M(r,l) == 0
            victory = 0;
            continue
        end    
        if range(M(r:(r+N-1),l)) == 0
            victory = M(r,l);
        end

    end
end



for r = 1:(rows-N+1)
    for l = 1:(cols-N+1)
        %disp(["r=", num2str(r), " l=", num2str(l)])
        if M(r,l) == 0
            victory = 0;
            %disp(diag(flip(M(r:(r+N-1),l:(l+N-1)))));
            %disp(range(diag(flip(M(r:(r+N-1),l:(l+N-1))))));
            continue
        end    
        if range(diag(M(r:(r+N-1),l:(l+N-1)))) == 0
            victory = M(r,l);
            %disp('victory')
        end
    end
end




for r = 1:(rows-N+1)
    for l = 1:(cols-N+1)
        %disp(["r=", num2str(r), " l=", num2str(l)])
        if M(r+N-1,l) == 0
            victory = 0;
            %disp(diag(flip(M(r:(r+N-1),l:(l+N-1)))));
            %disp(range(diag(flip(M(r:(r+N-1),l:(l+N-1))))));
            continue
        end    
        if range(diag(flip(M(r:(r+N-1),l:(l+N-1))))) == 0     
            victory = M(r+N-1,l);
            %disp('victory')
        end
    end
end
