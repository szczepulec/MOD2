
function renderBoard(M)
%RENDERBOARD Plot the board

[rows, cols] = size(M);

board = zeros(rows, cols, 3);

empty = [1, 1, 1];
yellow = [1, 1, 0.1];
red = [1, 0.1, 0.1];

% Squares
for row = 1:rows
    for col = 1:cols
        if M(row, col) == 0
            board(row, col, :) = empty;
        elseif M(row, col) == 1
            board(row, col, :) = yellow;
        else
            board(row, col, :) = red;
        end
    end
end

figure(1);
image(board);
axis equal;

hold on;

% Grid
for row = 0.5 : 1 : rows+0.5
    line([0.5, cols+0.5], [row, row], 'Color', 'k', 'LineWidth', 1);
end
for col = 0.5 : 1 : cols+0.5
    line([col, col], [0.5, rows+0.5], 'Color', 'k', 'LineWidth', 1);
end

hold off;

end


