clear all;  close all; clc;

%function [M, turn] = initializeBoard(N, K);

N = 6;
K = 20;
c = randi(N+2);
M = initializeBoard(N,K);

checkVictory(M, N)


function victory = checkVictory(M, N)




end
