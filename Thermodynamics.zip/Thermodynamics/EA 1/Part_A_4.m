clear all; 
close all;
clc;

A0 = 7542;
A0_min = 7622;
A0_max = 7462;
t=215;
AT = 915;
AT_max = 945;
AT_min = 885;

T=-(t *log(0.5))/(log(A0/AT));
T_max = -(t *log(0.5))/(log(A0_max/AT_max));
T_min = -(t *log(0.5))/(log(A0_min/AT_min));

Error = T-T_min;

fprintf('T = %.3f ± %.3f s',T,Error);