
clear all; 
close all;
clc;

T = [2002, 2016];
Q = [130, 198];

S_max = (88/13);
S_min = (48/15);
y_min = -6264.8;
y_max = -13435.38;


plot(T,Q)
xlim([2000,2030])
hold on
refline(S_max,y_max)
refline(S_min,y_min)


err_Q = 10*ones(size(Q));
err_T = 0.5*ones(size(T));
errorbar(T,Q,err_Q,err_Q,err_T,err_T)


fprintf('Q = %.1f ± %.1f ',243.8,28.6);

