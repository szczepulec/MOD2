
clear; 
close all;
clc;

A = 3:3:24;
B = [-5.3, 7.1, 8.9, 20.9, 30.6, 40.7, 50.4, 54.4];

plot(A,B)
err_B = 0.5*ones(size(B));
err_A = 0.3*ones(size(A));
errorbar(A,B,err_B, err_B, err_A, err_A)
ff = fit(A',B','poly1');
    
m = ff.p1;
A_0 = ff.p2;

myRefLine = refline(m,A_0);
myRefLine.Color = 'r';

intervals = confint(ff);
m_error = (intervals(2,1) - intervals(1,1)) / 2;
A_0_error = (intervals(2,2) - intervals(1,2)) / 2;

fprintf('Slope = %.3f ± %.3f ',m,m_error);
disp(' ')
fprintf('Y-intercept = %.3f ± %.3f ',A_0,A_0_error);


