

clear all; 
close all;
clc;


A_0 = 7542 
