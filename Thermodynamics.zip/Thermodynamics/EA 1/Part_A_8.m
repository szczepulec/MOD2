
clear; 
close all;
clc;

V = 0.015;
pV_list = 1e5 * V * [1.421, 1.480, 1.548, 1.597, 1.642, 1.698, 1.764, 1.815, 1.874];
T= -15.00: 10: 65;


plot(T,pV_list,'kx')
ff = fit(T',pV_list','poly1');

m = ff.p1;
pV_0 = ff.p2;

myRefLine = refline(m,pV_0);
myRefLine.Color = 'r';

intervals = confint(ff);
m_error = (intervals(2,1) - intervals(1,1)) / 2;
A_0_error = (intervals(2,2) - intervals(1,2)) / 2;


fprintf('R = %.3f ± %.3f m^3⋅Pa⋅K^(−1)⋅mol^(−1)',m,m_error);
disp(' ')
fprintf('Absolute zero Temperature = %.3f ± %.3f °C',pV_0,A_0_error);


