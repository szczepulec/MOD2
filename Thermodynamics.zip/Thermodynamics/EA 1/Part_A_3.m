

clear all; 
close all;
clc;


a_list = [-1.48, -1.71, -1.43, -1.46, -1.94, -1.92, -1.92, -1.70, -1.13, -1.71, -1.98, -1.64, -1.81]; %

M = mean(a_list);
STD = std(a_list);
SEM = std(a_list) / sqrt(length(a_list));
t= 2.179;
C = t * SEM;

fprintf('M = %.2f ± %.2f m/s2',M,C);
